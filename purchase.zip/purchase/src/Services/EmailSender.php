<?php

namespace Drupal\purchase\Services;

use PHPMailer\PHPMailer\Exception;
use PHPMailer\PHPMailer\PHPMailer;

/**
 * Class EmailSender.
 */
class EmailSender {

  /**
   * Constructs a new EmailSender object.
   */

  public function sendRequestNotification() {
    require './vendor/autoload.php';

    $mail = new PHPMailer(TRUE);
    try {
      $mail->isSMTP();
      $mail->SMTPDebug = 0;
      $mail->Host = 'smtp.gmail.com';
      $mail->SMTPAuth = TRUE;
      $mail->Username = 'testprojet77@gmail.com';
      $mail->Password = 'rxzl mwwn hfic ykjz';
      $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;
      $mail->Port = 587;

      $mail->setFrom('testprojet77@gmail.com', 'AISME');
      $mail->addAddress('nadjlalabri@gmail.com', 'Me');  //vinicius.affonso-de-carvalho@grenoble-inp.fr

      $mail->isHTML(false);
      $mail->Subject = 'Notification new subscription';
      $mail->Body = "A new subscription has been placed.\n AISME Team ";
      $mail->send();
    }
    catch (Exception $e) {
      echo "Message could not be sent. Mailer Error: {$mail->ErrorInfo}";
    }
  }
  public function sendPurchaseNotification() {
    require './vendor/autoload.php';

    $mail = new PHPMailer(TRUE);
    try {
      $mail->isSMTP();
      $mail->SMTPDebug = 0;
      $mail->Host = 'smtp.gmail.com';
      $mail->SMTPAuth = TRUE;
      $mail->Username = 'testprojet77@gmail.com';
      $mail->Password = 'rxzl mwwn hfic ykjz';
      $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;
      $mail->Port = 587;

      $mail->setFrom('testprojet77@gmail.com', 'AISME');
      $mail->addAddress('nadjlalabri@gmail.com', 'Me');  //micheline.echard@grenoble-inp.fr

      $mail->isHTML(false);
      $mail->Subject = 'Notification New subscription';
      $mail->Body = "A new subscription has been approved\n AISME Team";
      $mail->send();
    }
    catch (Exception $e) {
      echo "Message could not be sent. Mailer Error: {$mail->ErrorInfo}";
    }
  }

  /**
   * @throws \Twig\Error\RuntimeError
   * @throws \Twig\Error\SyntaxError
   * @throws \Twig\Error\LoaderError
   */
  public function sendConfirmation($email, $name) {
    require './vendor/autoload.php';
    $loader = new \Twig\Loader\FilesystemLoader('C:\Users\labrin-admin\Downloads\aisme\modules\purchase\templates');
    $twig = new \Twig\Environment($loader);

    $emailBody = $twig->render('EmailContent.html.twig', ['name' => $name]);


    $mail = new PHPMailer();
    $mail->CharSet = "UTF-8";
    $mail->IsSMTP();
    $mail->SMTPDebug = 0;
    $mail->SMTPAuth = true;
    $mail->SMTPSecure = PHPMailer::ENCRYPTION_SMTPS ;
    $mail->Host = 'ssl0.ovh.net';
    $mail->Port = 465;
    $mail->Username = 'nadir.fouka@fouka.ovh';
    $mail->Password = '78igHnlN1rr4%Cm64Mg9*fQ6';
    $mail->SetFrom('gi-dev@grenoble-inp.fr', 'GI DEV AISME');
    $mail->Subject = 'Confirmation of subscription';
    $mail->msgHTML($emailBody ) ;
    $mail->AddAddress($email);
    //$mail->AddCC("gi-dev@grenoble-inp.fr");
    $mail->AddCC("nadjla-selma.labri@grenoble-inp.fr");
    $mail->Priority = 1;
    $mail->AddCustomHeader("X-MSMail-Priority: High");
    $mail->AddCustomHeader("Importance: High");
    if(!$mail->Send()) {
      return false;
    } else {

      return true;
    }

  }

}
