<?php

namespace Drupal\purchase\Controller;

use Drupal\Core\Controller\ControllerBase;
use Drupal\Core\Url;
use Drupal\purchase\Services\EmailSender;
use Symfony\Component\DependencyInjection\ContainerInterface;
use Symfony\Component\HttpFoundation\RedirectResponse;
/**
 * Class recapController.
 */
class recapController extends ControllerBase {
  protected $EmailSender;

  public function __construct(EmailSender $email_service) {
    $this->EmailSender = $email_service;
  }

  public static function create(ContainerInterface $container) {
    return new static($container->get('purchase.email_service'));
  }
  /**
   * Recap.
   *
   * @return string[]
   *   Return Hello string.
   */
  public function recap($id) {
    $query = \Drupal::database()->select('purchase', 'p');
    $query->join('clients', 'c', 'c.id = p.client_id');
    $query->join('courses', 'cr', 'cr.id = p.course_id');
    $query->fields('p', ['datetime', "month", "state"]);
    $query->fields('c', ['enterprise_name', 'last_name','first_name','country_citizenship','country_residence', 'address_residence','gender', 'email']);
    $query->fields('cr', ['course_name']);
    $query->condition('p.id', $id);
    $result = $query->execute()->fetchAssoc();

    $data = [
      'purchase' => $result,
      'approve_url' => Url::fromRoute('purchase.recap_controller_approve', ['id' => $id])->toString(),
      'decline_url' => Url::fromRoute('purchase.recap_controller_decline', ['id' => $id])->toString(),
      'return_url' => Url::fromRoute('purchase.purchase_list_controller_content', ['id' => $id])->toString(),
    ];
    drupal_flush_all_caches();
    return [
      '#theme' => 'purchase_recap',
      '#data' => $data,
    ];

  }

  public function approve($id){
    $query = \Drupal::database()->update('purchase');
    $query->fields(['state' => 'approved']);
    $query ->condition('purchase.id', $id);
    $query->execute();
    $this->EmailSender->sendPurchaseNotification();
    $this->messenger()->addMessage($this->t('Successfully approved the purchase.'));
    drupal_flush_all_caches();

    return new RedirectResponse(\Drupal::url('purchase.purchase_list_controller_content'));
  }
  public function decline($id){
    $query = \Drupal::database()->update('purchase');
    $query->fields(['state' => 'declined']);
    $query ->condition('purchase.id', $id);
    $query->execute();
    $this->messenger()->addMessage($this->t('Successfully declined the purchase.'));
    drupal_flush_all_caches();

    return new RedirectResponse(\Drupal::url('purchase.purchase_list_controller_content'));

  }


}
