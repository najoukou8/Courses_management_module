<?php
namespace Drupal\purchase\Controller;

use Drupal\Core\Controller\ControllerBase;
use Drupal\Core\Url;
use Symfony\Component\HttpFoundation\Request;

class PurchaseListController extends ControllerBase {

  public function content(Request $request) {
    $search = $request->query->get('search', '');
    $sort_column = $request->query->get('sort_column', 'client_name');
    $sort_order = $request->query->get('sort_order', 'asc');

    $sort_column_map = [
      'client_name' => 'c.first_name',
      'course_name' => 'cr.course_name',
      'datetime' => 'p.datetime',
      'state' => 'p.state',
    ];

    $sort_column_db = $sort_column_map[$sort_column] ?? 'c.first_name';

    $query = \Drupal::database()->select('purchase', 'p');
    $query->join('clients', 'c', 'c.id = p.client_id');
    $query->join('courses', 'cr', 'cr.id = p.course_id');
    $query->fields('p', ['id', 'datetime', 'state'])
      ->fields('c', ['first_name', 'last_name'])
      ->fields('cr', ['course_name']);

    if (!empty($search)) {
      $query->condition(
        $query->orConditionGroup()
          ->condition('c.first_name', '%' . \Drupal::database()->escapeLike($search) . '%', 'LIKE')
          ->condition('c.last_name', '%' . \Drupal::database()->escapeLike($search) . '%', 'LIKE')
          ->condition('p.state', '%' . \Drupal::database()->escapeLike($search) . '%', 'LIKE')
          ->condition('cr.course_name', '%' . \Drupal::database()->escapeLike($search) . '%', 'LIKE')
      );
    }

    $query->orderBy($sort_column_db, $sort_order);

    $pager = $query->extend('Drupal\Core\Database\Query\PagerSelectExtender')->limit(10);
    $results = $pager->execute()->fetchAll();

    $header = [
      ['data' => $this->t('Action')],
      ['data' => $this->t('Client Name')],
      ['data' => $this->t('Course Name')],
      ['data' => $this->t('Datetime')],
      ['data' => $this->t('State')],
    ];

    $rows = [];

    foreach ($results as $record) {
      $state_color='';
      switch ($record->state) {
        case 'approved':
          $state_color='background-color :#b0f2b6;';
          break;
        case 'waiting':
          $state_color='background-color :#FFFAA0;';
          break;
        case 'declined':
          $state_color='background-color :#ff6961;';
          break;
        case 'paid':
          $state_color='background-color :#c4c4c4;';
          break;
      }
      $rows[] = [
        'id' => [
          'data' => [
            '#type' => 'link',
            '#title' => 'view',
            '#url' => Url::fromRoute('purchase.recap_controller_recap', ['id' => $record->id]),
          ],
        ],
        'client_name' => $record->first_name . ' ' . $record->last_name,
        'course_name' => $record->course_name,
        'datetime' => $record->datetime,
        'state' =>[
          'data'=> strtoupper( $record->state),
          'style' => $state_color],
      ];
    }

    $form = \Drupal::formBuilder()->getForm('Drupal\purchase\Form\PurchaseListForm');
    $form['table'] = [
      '#type' => 'table',
      '#header' => $header,
      '#rows' => $rows,
      '#empty' => $this->t('No purchases found')

    ];
    $form['pager'] = [
      '#type' => 'pager',
    ];

    return [
      '#theme' => 'PurchaseListPage',
      '#form' => $form,
    ];
  }
}
