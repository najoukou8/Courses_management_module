<?php

namespace Drupal\purchase\Controller;

use Drupal\Core\Controller\ControllerBase;

/**
 * Class MonthsController.
 */
class MonthsController extends ControllerBase {

  public function monthsRange() {
    $form = $this->formBuilder()->getForm('\Drupal\purchase\Form\MonthsForm');

    return [
      '#theme' => 'monthsformPage',
      '#form' => $form,
    ];
  }

}
