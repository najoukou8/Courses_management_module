<?php

namespace Drupal\purchase\Controller;

use Drupal\Core\Controller\ControllerBase;
use Drupal\Core\Url;
use Drupal\purchase\Services\EmailSender;
use Symfony\Component\DependencyInjection\ContainerInterface;
use Symfony\Component\HttpFoundation\RedirectResponse;
/**
 * Class recapController.
 */
class ApprovedRecapController extends ControllerBase {
  protected $EmailSender;

  public function __construct(EmailSender $email_service) {
    $this->EmailSender = $email_service;
  }

  public static function create(ContainerInterface $container) {
    return new static($container->get('purchase.email_service'));
  }
  /**
   * Recap.
   *
   * @return string[]
   *   Return Hello string.
   */
  public function recap($id) {
    $query = \Drupal::database()->select('purchase', 'p');
    $query->join('clients', 'c', 'c.id = p.client_id');
    $query->join('courses', 'cr', 'cr.id = p.course_id');
    $query->fields('p', ['datetime', "month", "state"]);
    $query->fields('c', ['enterprise_name', 'last_name','first_name','country_citizenship','country_residence', 'address_residence','gender', 'email']);
    $query->fields('cr', ['course_name']);
    $query->condition('p.id', $id);
    $result = $query->execute()->fetchAssoc();

    $data = [
      'purchase' => $result,
      'paid_url' => Url::fromRoute('purchase.recap_controller_paid', ['id' => $id])->toString(),
      'return_url' => Url::fromRoute('purchase.approved_list_controller_content', ['id' => $id])->toString(),
    ];
    drupal_flush_all_caches();
    return [
      '#theme' => 'approved_purchase_recap',
      '#data' => $data,
    ];

  }

  public function paid($id){
    $query = \Drupal::database()->update('purchase');
    $query->fields(['state' => 'paid']);
    $query ->condition('purchase.id', $id);
    $query->execute();
    $this->messenger()->addMessage($this->t('Successfully the purchase paid.'));
    drupal_flush_all_caches();

    return new RedirectResponse(\Drupal::url('purchase.approved_list_controller_content'));

  }


}
