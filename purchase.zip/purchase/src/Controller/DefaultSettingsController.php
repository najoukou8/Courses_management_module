<?php

namespace Drupal\purchase\Controller;

use Drupal\Core\Controller\ControllerBase;

/**
 * Class DefaultSettingsController.
 */
class DefaultSettingsController extends ControllerBase {


  public function CoursesSettings () {
    $form = $this->formBuilder()->getForm('\Drupal\purchase\Form\DefaultCoursesSettingsForm');

   // return $form;
    return [
      '#theme' => 'DefaultCoursesSettingsPage',
      '#form' => $form,
    ];

}
}
