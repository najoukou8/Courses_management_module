<?php

namespace Drupal\purchase\Controller;

use Drupal\Core\Controller\ControllerBase;

/**
 * Class CoursesListController.
 */
class CoursesListController extends ControllerBase {

  public function content() {
    
    $form = $this->formBuilder()->getForm("\Drupal\purchase\Form\CoursesListForm");
    
    // return $form;
    return [
      '#theme' => 'coursesListPage',
      '#form' => $form,
    ];
  }

}
