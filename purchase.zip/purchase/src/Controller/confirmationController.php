<?php

namespace Drupal\purchase\Controller;

use Drupal\Core\Controller\ControllerBase;

/**
 * Class confirmationController.
 */
class confirmationController extends ControllerBase {

  public function content() {
    return [
      '#type' => 'markup',
      '#markup' => '<div class="confirmation-container">
                      <h1>Thank You!</h1>
                      <a href="/" class="home-button">Go to Home Page</a>
                      </div>',
      drupal_set_message( ' Your subscription has been submitted successfully. Check your inbox, you will receive an email with further details.' )
    ];
  }

}
