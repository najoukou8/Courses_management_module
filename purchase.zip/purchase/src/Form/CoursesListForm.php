<?php

namespace Drupal\purchase\Form;

use Drupal\Core\Datetime\DrupalDateTime;
use Drupal\Core\Form\ConfigFormBase;
use Drupal\Core\Form\FormStateInterface;
use Drupal\purchase\Services\EmailSender;
use Symfony\Component\DependencyInjection\ContainerInterface;

/**
 * Class CoursesListForm.
 */
class CoursesListForm extends ConfigFormBase {

  public $step = 1;
  public $countries =[
"AF" => "Afghanistan",
"AL" => "Albania",
"DZ" => "Algeria",
"AS" => "American Samoa",
"AD" => "Andorra",
"AO" => "Angola",
"AI" => "Anguilla",
"AQ" => "Antarctica",
"AG" => "Antigua and Barbuda",
"AR" => "Argentina",
"AM" => "Armenia",
"AW" => "Aruba",
"AU" => "Australia",
"AT" => "Austria",
"AZ" => "Azerbaijan",
"BS" => "Bahamas",
"BH" => "Bahrain",
"BD" => "Bangladesh",
"BB" => "Barbados",
"BY" => "Belarus",
"BE" => "Belgium",
"BZ" => "Belize",
"BJ" => "Benin",
"BM" => "Bermuda",
"BT" => "Bhutan",
"BO" => "Bolivia",
"BA" => "Bosnia and Herzegovina",
"BW" => "Botswana",
"BV" => "Bouvet Island",
"BR" => "Brazil",
"IO" => "British Indian Ocean Territory",
"BN" => "Brunei Darussalam",
"BG" => "Bulgaria",
"BF" => "Burkina Faso",
"BI" => "Burundi",
"KH" => "Cambodia",
"CM" => "Cameroon",
"CA" => "Canada",
"CV" => "Cape Verde",
"KY" => "Cayman Islands",
"CF" => "Central African Republic",
"TD" => "Chad",
"CL" => "Chile",
"CN" => "China",
"CX" => "Christmas Island",
"CC" => "Cocos (Keeling) Islands",
"CO" => "Colombia",
"KM" => "Comoros",
"CG" => "Congo",
"CD" => "Congo, the Democratic Republic of the",
"CK" => "Cook Islands",
"CR" => "Costa Rica",
"CI" => "Cote D'Ivoire",
"HR" => "Croatia",
"CU" => "Cuba",
"CY" => "Cyprus",
"CZ" => "Czech Republic",
"DK" => "Denmark",
"DJ" => "Djibouti",
"DM" => "Dominica",
"DO" => "Dominican Republic",
"EC" => "Ecuador",
"EG" => "Egypt",
"SV" => "El Salvador",
"GQ" => "Equatorial Guinea",
"ER" => "Eritrea",
"EE" => "Estonia",
"ET" => "Ethiopia",
"FK" => "Falkland Islands (Malvinas)",
"FO" => "Faroe Islands",
"FJ" => "Fiji",
"FI" => "Finland",
"FR" => "France",
"GF" => "French Guiana",
"PF" => "French Polynesia",
"TF" => "French Southern Territories",
"GA" => "Gabon",
"GM" => "Gambia",
"GE" => "Georgia",
"DE" => "Germany",
"GH" => "Ghana",
"GI" => "Gibraltar",
"GR" => "Greece",
"GL" => "Greenland",
"GD" => "Grenada",
"GP" => "Guadeloupe",
"GU" => "Guam",
"GT" => "Guatemala",
"GN" => "Guinea",
"GW" => "Guinea-Bissau",
"GY" => "Guyana",
"HT" => "Haiti",
"HM" => "Heard Island and Mcdonald Islands",
"VA" => "Holy See (Vatican City State)",
"HN" => "Honduras",
"HK" => "Hong Kong",
"HU" => "Hungary",
"IS" => "Iceland",
"IN" => "India",
"ID" => "Indonesia",
"IR" => "Iran, Islamic Republic of",
"IQ" => "Iraq",
"IE" => "Ireland",
"IL" => "Israel",
"IT" => "Italy",
"JM" => "Jamaica",
"JP" => "Japan",
"JO" => "Jordan",
"KZ" => "Kazakhstan",
"KE" => "Kenya",
"KI" => "Kiribati",
"KP" => "Korea, Democratic People's Republic of",
"KR" => "Korea, Republic of",
"KW" => "Kuwait",
"KG" => "Kyrgyzstan",
"LA" => "Lao People's Democratic Republic",
"LV" => "Latvia",
"LB" => "Lebanon",
"LS" => "Lesotho",
"LR" => "Liberia",
"LY" => "Libyan Arab Jamahiriya",
"LI" => "Liechtenstein",
"LT" => "Lithuania",
"LU" => "Luxembourg",
"MO" => "Macao",
"MK" => "Macedonia, the Former Yugoslav Republic of",
"MG" => "Madagascar",
"MW" => "Malawi",
"MY" => "Malaysia",
"MV" => "Maldives",
"ML" => "Mali",
"MT" => "Malta",
"MH" => "Marshall Islands",
"MQ" => "Martinique",
"MR" => "Mauritania",
"MU" => "Mauritius",
"YT" => "Mayotte",
"MX" => "Mexico",
"FM" => "Micronesia, Federated States of",
"MD" => "Moldova, Republic of",
"MC" => "Monaco",
"MN" => "Mongolia",
"MS" => "Montserrat",
"MA" => "Morocco",
"MZ" => "Mozambique",
"MM" => "Myanmar",
"NA" => "Namibia",
"NR" => "Nauru",
"NP" => "Nepal",
"NL" => "Netherlands",
"AN" => "Netherlands Antilles",
"NC" => "New Caledonia",
"NZ" => "New Zealand",
"NI" => "Nicaragua",
"NE" => "Niger",
"NG" => "Nigeria",
"NU" => "Niue",
"NF" => "Norfolk Island",
"MP" => "Northern Mariana Islands",
"NO" => "Norway",
"OM" => "Oman",
"PK" => "Pakistan",
"PW" => "Palau",
"PS" => "Palestinian Territory, Occupied",
"PA" => "Panama",
"PG" => "Papua New Guinea",
"PY" => "Paraguay",
"PE" => "Peru",
"PH" => "Philippines",
"PN" => "Pitcairn",
"PL" => "Poland",
"PT" => "Portugal",
"PR" => "Puerto Rico",
"QA" => "Qatar",
"RE" => "Reunion",
"RO" => "Romania",
"RU" => "Russian Federation",
"RW" => "Rwanda",
"SH" => "Saint Helena",
"KN" => "Saint Kitts and Nevis",
"LC" => "Saint Lucia",
"PM" => "Saint Pierre and Miquelon",
"VC" => "Saint Vincent and the Grenadines",
"WS" => "Samoa",
"SM" => "San Marino",
"ST" => "Sao Tome and Principe",
"SA" => "Saudi Arabia",
"SN" => "Senegal",
"CS" => "Serbia and Montenegro",
"SC" => "Seychelles",
"SL" => "Sierra Leone",
"SG" => "Singapore",
"SK" => "Slovakia",
"SI" => "Slovenia",
"SB" => "Solomon Islands",
"SO" => "Somalia",
"ZA" => "South Africa",
"GS" => "South Georgia and the South Sandwich Islands",
"ES" => "Spain",
"LK" => "Sri Lanka",
"SD" => "Sudan",
"SR" => "Suriname",
"SJ" => "Svalbard and Jan Mayen",
"SZ" => "Swaziland",
"SE" => "Sweden",
"CH" => "Switzerland",
"SY" => "Syrian Arab Republic",
"TW" => "Taiwan, Province of China",
"TJ" => "Tajikistan",
"TZ" => "Tanzania, United Republic of",
"TH" => "Thailand",
"TL" => "Timor-Leste",
"TG" => "Togo",
"TK" => "Tokelau",
"TO" => "Tonga",
"TT" => "Trinidad and Tobago",
"TN" => "Tunisia",
"TR" => "Turkey",
"TM" => "Turkmenistan",
"TC" => "Turks and Caicos Islands",
"TV" => "Tuvalu",
"UG" => "Uganda",
"UA" => "Ukraine",
"AE" => "United Arab Emirates",
"GB" => "United Kingdom",
"US" => "United States",
"UM" => "United States Minor Outlying Islands",
"UY" => "Uruguay",
"UZ" => "Uzbekistan",
"VU" => "Vanuatu",
"VE" => "Venezuela",
"VN" => "Viet Nam",
"VG" => "Virgin Islands, British",
"VI" => "Virgin Islands, U.s.",
"WF" => "Wallis and Futuna",
"EH" => "Western Sahara",
"YE" => "Yemen",
"ZM" => "Zambia",
"ZW" => "Zimbabwe"
];
  protected $EmailSender;

  public function __construct(EmailSender $email_service) {
    $this->EmailSender = $email_service;
  }

  public static function create(ContainerInterface $container) {
    return new static(
      $container->get('purchase.email_service')
    );
  }


  protected function getEditableConfigNames() {}

  /**
   * {@inheritdoc}
   */
  public function getFormID() {
    return 'courses_list_form';
  }

  /**
   * {@inheritdoc}
   */
  public function buildForm(array $form, FormStateInterface $form_state) {

    $form = parent::buildForm($form, $form_state);

    $storage = $form_state->getStorage();
    $this->step = $storage['step'] ?? 1;

    $months_result= db_query('SELECT course_id, month_year FROM {months}');
    $months= [];
    foreach ($months_result as $record) {
      $months[$record->course_id][] = strtolower(str_replace('_', ' ', $record->month_year));
    };

    $result = db_query('SELECT id, course_name, course_description FROM {courses}');
    $data = [];
    foreach ($result as $record) {
      $data[] = (array) $record;
    }

    if($this->step == 1) {

      $form['courses'] = [
        '#type' => 'value',
        '#value' => $data,
        '#weight' => '0',
      ];

      foreach ($data as $course) {
        $course_id = $course['id'];
        $course_months = $months[$course_id] ?? [];

        $form["months_list_{$course_id}"] = [
          '#type' => 'radios',
          '#title' => $this->t('Select month for course: ') . $course['course_name'],
          '#options' => array_combine($course_months, $course_months),
          '#attributes' => ['class' => 'hidden-radios'],
        ];
      }
    }
    elseif($this->step == 2) {
      $storage = $form_state->getStorage();
     $form['title']= [
        '#markup' => '<h1>Fill your personal information</h1>',
      ];
    $form['enterprise_name'] = [
      '#type' => 'textfield',
      '#title' => $this->t('Enterprise name'),
      '#description' => $this->t('the enterprise name'),
      '#default_value' => $storage['enterprise_name'] ?? '',
      '#maxlength' => 64,
      '#size' => 64,
      '#weight' => '0',
    ];
    $form['first_name'] = [
      '#type' => 'textfield',
      '#title' => $this->t('First name'),
      '#description' => $this->t('the client first name'),
      '#default_value' => $storage['first_name'] ?? '',
      '#maxlength' => 64,
      '#size' => 64,
      '#weight' => '0',
    ];
    $form['last_name'] = [
      '#type' => 'textfield',
      '#title' => $this->t('Last name'),
      '#description' => $this->t('the client last name'),
      '#default_value' => $storage['last_name'] ?? '',
      '#maxlength' => 64,
      '#size' => 64,
      '#weight' => '0',
    ];
    $form['country_citizenship'] = [
      '#type' => 'select',
      '#title' => $this->t('Country of citizenship'),
      '#options' => ['' => $this->t('- Select -')] + $this->countries,
      '#size' => 1,
      '#weight' => '0',
    ];
    $form['country_residence'] = [
      '#type' => 'select',
      '#title' => $this->t('Country of residence'),
      '#options' => ['' => $this->t('- Select -')] + $this->countries,
      '#size' => 1,
      '#weight' => '0',
    ];
    $form['gender'] = [
      '#type' => 'select',
      '#title' => $this->t('Gender'),
      '#options' => ['' => $this->t('- Select -'),'female' => $this->t('female'), 'male' => $this->t('male'), 'prefer not to say' => $this->t('Prefer not to say')],
      '#size' => 1,
      '#weight' => '0',
    ];
    $form['email'] = [
      '#type' => 'email',
      '#title' => $this->t('email'),
      '#weight' => '0',
    ];
    $form['address_residence'] = [
      '#type' => 'textfield',
      '#title' => $this->t('Personal address'),
      '#maxlength' => 64,
      '#size' => 64,
      '#weight' => '0',
    ];

  }
    elseif($this->step==3){


    $form['review']['review_courses']= [
      '#markup' => '<h1>Review your chosen courses</h1>',
    ];

    $selected_months = $storage['selected_months'] ?? [];
    foreach ($selected_months as $course_id => $data) {
     $form['review']['selected_course_' . $course_id] = [
        '#markup' => '<p> <b>Selected course: </b>' . $data['course_name'].'<b> in </b>'.$data['selected_month'] . '</p>',
      ];
      }
     $form['review']['review_info']= [
        '#markup' => '<h1>Review your personal information</h1>',
      ];
    $form['review']['enterprise_name'] = [
        '#markup' => '<p> <b>Enterprise Name:</b> ' . $storage['enterprise_name'] . '</p>',
      ];
    $form['review']['first_name'] = [
      '#markup' => '<p> <b>First Name: </b>' . $storage['first_name'] . '</p>',
    ];
    $form['review']['last_name'] = [
      '#markup' => '<p> <b>Last Name: </b>' . $storage['last_name'] . '</p>',
    ];
    $form['review']['gender'] = [
      '#markup' => '<p> <b>Gender:</b> ' . $storage['gender'] . '</p>',
    ];
    $form['review']['email'] = [
      '#markup' => '<p> <b>Email:</b> ' . $storage['email'] . '</p>',
    ];
    $form['review']['country_citizenship'] = [
      '#markup' => '<p> <b>Country of Citizenship: </b>' . $storage['country_citizenship'] . '</p>',
    ];
    $form['review']['country_residence'] = [
      '#markup' => '<p> <b>Country of Residence: </b>' . $storage['country_residence'] . '</p>',
    ];
    $form['review']['address_residence'] = [
      '#markup' => '<p> <b>Personal Address: </b>' . $storage['address_residence'] . '</p>',
    ];


    $captcha_question = $this->generateCapchaQuestion();
    $storage['captcha_question'] = $captcha_question;
    $storage['captcha_answer'] = $this->get_catpcha_answer();
    $form_state->setStorage($storage);


  $form['Captcha_question'] = [
        '#type' => 'markup',
        '#markup' => $this->t('<label>CAPTCHA: Solve this simple problem: %question</label>', ['%question' => $captcha_question]),
      ];

  $form['captcha_answer'] = [
    '#type' => 'textfield',
    '#maxlength' => 10,
    '#size' => 10,
    ];

  }

   $form['actions']['submit'] = [
    '#type' => 'submit',
    '#value' => $this->step < 3 ? $this->t('Next') : $this->t('Submit'),
  ];
  if ($this->step > 1) {
   $form['actions']['previous'] = [
      '#type' => 'submit',
      '#value' => $this->t('Previous'),
      '#validate' => [],
      '#submit' => ['::previousSubmit'],
      '#limit_validation_errors' => [],
      '#weight' => -1,
    ];
  }
   $form['#theme'] = 'coursesListPage';

      return $form;
    }

  public function generateCapchaQuestion() {
    $a = rand(1, 30);
    $b = rand(1, 30);
    $this->captcha_answer = $a + $b;
    return "$a + $b";
  }

  public function get_catpcha_answer(){
    return $this->captcha_answer;
  }

  public function previousSubmit(array &$form, FormStateInterface $form_state): void {
    $this->step--;
    $storage = $form_state->getStorage();
    $storage['step'] = $this->step;
    $form_state->setStorage($storage);
    $form_state->setRebuild();
  }

  /**
   * {@inheritdoc}
   */
  public function validateForm(array &$form, FormStateInterface $form_state): void {

    $enterprise_name= $form_state->getValue('enterprise_name');
    $first_name= $form_state->getValue('first_name');
    $last_name= $form_state->getValue('last_name');
    $gender= $form_state->getValue('gender');
    $email= $form_state->getValue('email');
    $country_citizenship= $form_state->getValue('country_citizenship');
    $country_residence= $form_state->getValue('country_residence');
    $address_residence= $form_state->getValue('address_residence');

    if ($this->step == 1) {
      $courses = $form_state->getValue('courses');
      $selected_months = [];
      foreach ($courses as $course) {
        $course_id = $course['id'];
        $selected_month = $form_state->getValue("months_list_{$course_id}");
        if ($selected_month) {
          $selected_months[$course_id] = $selected_month;
        }
      }
      if (empty($selected_months)) {
        $form_state->setErrorByName('', $this->t('Please select at least one course with one month.'));
      }
    }
    if($this->step==2 ) {
      if (empty($enterprise_name)) {
        $form_state->setErrorByName("enterprise_name", $this->t('Please enter the name of the enterprise'));
      }
      if (empty($first_name)) {
        $form_state->setErrorByName("first_name", $this->t('Please enter the first name'));
      }
      if (empty($last_name)) {
        $form_state->setErrorByName("last_name", $this->t('Please enter the last name'));
      }
      if (empty($gender)) {
        $form_state->setErrorByName("gender", $this->t('Please select the gender'));
      }


      if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $form_state->setErrorByName("email", $this->t('Please enter a valid email address.'));
      } else {
        $domain = substr(strrchr($email, "@"), 1);
        if (!checkdnsrr($domain, "MX")) {
          $form_state->setErrorByName("email", $this->t('The email domain does not exist or cannot receive emails.'));
        }
      }

      if (empty($country_citizenship)) {
        $form_state->setErrorByName("country_citizenship", $this->t('Please select the country citizenship'));
      }
      if (empty($country_residence)) {
        $form_state->setErrorByName("country_residence", $this->t('Please select the country residence'));
      }
      if (empty($address_residence)) {
        $form_state->setErrorByName("address_residence", $this->t('Please enter the address'));
      }
    }
    if ($this->step==3){

      $storage = $form_state->getStorage();
      $user_answer= $form_state->getValue('captcha_answer');
      $correct_answer= $storage['captcha_answer'];
      if ($user_answer != $correct_answer) {
        $form_state->setErrorByName('captcha_answer', $this->t('Incorrect CAPTCHA answer.'));
          }
    }
    }

  /**
   * {@inheritdoc}
   * @throws \Exception
   */
  public function submitForm(array &$form, FormStateInterface $form_state) {

    $storage = $form_state->getStorage();
    if ($this->step == 1) {
      $courses = $form_state->getValue('courses');
      $selected_months = [];
      foreach ($courses as $course) {
        $course_id = $course['id'];
        $selected_month = $form_state->getValue("months_list_{$course_id}");
        if ($selected_month) {
          $selected_months[$course_id] = [
            'course_name' => $course['course_name'],
            'selected_month' =>strtolower(str_replace('_', ' ', $selected_month)),

          ];
        }
      }
      $storage['selected_months'] = $selected_months;
      $form_state->setStorage($storage);
    }
    if ($this->step == 2) {
      $storage['enterprise_name'] = $form_state->getValue('enterprise_name');
      $storage['first_name'] = $form_state->getValue('first_name');
      $storage['last_name'] = $form_state->getValue('last_name');
      $storage['country_citizenship'] =  $this->countries[$form_state->getValue('country_citizenship')];
      $storage['country_residence'] =  $this->countries[$form_state->getValue('country_residence')];
      $storage['gender'] = $form_state->getValue('gender');
      $storage['email'] = $form_state->getValue('email');
      $storage['address_residence'] = $form_state->getValue('address_residence');
      $form_state->setStorage($storage);

    }
    if ($this->step == 3) {
      $client_id = \Drupal::database()->insert('clients')
        ->fields([
          'enterprise_name' => $storage['enterprise_name'],
          'first_name' => $storage['first_name'],
          'last_name' => $storage['last_name'],
          'country_citizenship' => $storage['country_citizenship'],
          'country_residence' => $storage['country_residence'],
          'gender' => $storage['gender'],
          'email' => $storage['email'],
          'address_residence' => $storage['address_residence'],
        ])
        ->execute();
      $currentDateTime = new DrupalDateTime();
      $currentDateTimeString = $currentDateTime->format('Y-m-d H:i:s');

     foreach ($storage['selected_months'] as $course_id => $data) {
          \Drupal::database()->insert('purchase')
            ->fields([
              'client_id' => $client_id,
              'course_id' => $course_id,
              'month' => $data['selected_month'],
              'datetime'=>  $currentDateTimeString,
              'state' => 'waiting',
            ])
            ->execute();
        }
   $this->EmailSender->sendRequestNotification();
   $this->EmailSender->sendConfirmation($storage['email'], $storage['first_name']);
   $form_state->setStorage([]);

   $this->step = 1;
   $form_state->setRedirect('purchase.confirmation_controller_content');

      }
    else {
        $this->step++;
        $storage['step'] = $this->step;
        $form_state->setStorage($storage);
       $form_state->setRebuild();
      }
    }


}

