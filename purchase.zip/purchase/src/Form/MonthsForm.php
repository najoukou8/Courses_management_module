<?php

namespace Drupal\purchase\Form;

use Drupal\Core\Form\FormBase;
use Drupal\Core\Form\FormStateInterface;

/**
 * Class MonthsForm.
 */
class MonthsForm extends FormBase {

  /**
   * {@inheritdoc}
   */
  public function getFormId() {
    return 'months_form';
}

  /**
   * {@inheritdoc}
   */
  public function buildForm(array $form, FormStateInterface $form_state) {

    $database = \Drupal::database();
    $start_year = (int) $database->query('SELECT start_year FROM {courses_settings}')->fetchField();
    $end_year = (int) $database->query('SELECT end_year FROM {courses_settings}')->fetchField();


    $courses = [];
    $query = $database->select('courses', 'c')
      ->fields('c', ['id', 'course_name']);
    $result = $query->execute();
    foreach ($result as $record) {
      $courses[$record->id] = $record->course_name;
    }
    $months=[];
    $current_year= $start_year;
    while ($current_year <= $end_year) {
        for ($current_month = 1; $current_month <= 12; $current_month++) {
            $key = strtolower(date('F_Y', mktime(0, 0, 0, $current_month, 1, $current_year)));
            $months[$key] = date('F Y', mktime(0, 0, 0, $current_month, 1, $current_year));
        }
        $current_year++;
      }


    foreach ($courses as $course_id => $course_name) {
      $selected_months = [];
      $result = \Drupal::database()->select('months', 'm')
        ->fields('m', ['month_year'])
        ->condition('course_id', $course_id)
        ->execute();
      foreach ($result as $record) {
        $selected_months[] = strtolower(str_replace(' ', '_', $record->month_year));
      }

      $form['course_' . $course_id] = [
        '#type' => 'checkboxes',
        '#title' => $course_name,
        '#options' => $months,
        '#default_value' => $selected_months,
      ];
    }
    $form['courses'] = [
      '#type' => 'value',
      '#value' => $courses,
      '#weight' => '0',
    ];



    $form['submit'] = [
      '#type' => 'submit',
      '#value' => $this-> t('save'),
    ];

    $form['#theme'] = 'monthsformPage';
    \Drupal::logger('purchase')->debug('Form options: <pre>@options</pre>', ['@options' => print_r($months, TRUE)]);

    return $form;
  }

  /**
   * {@inheritdoc}
   */
  public function validateForm(array &$form, FormStateInterface $form_state) {
    foreach ($form_state->getValues() as $key => $value) {
    }
    parent::validateForm($form, $form_state);
  }

  /**
   * {@inheritdoc}
   */
  public function submitForm(array &$form, FormStateInterface $form_state) {
    $courses = $form_state->getValue('courses');
    foreach ($courses as $course_id => $course_name) {
      $new_months = array_keys(array_filter($form_state->getValue('course_' . $course_id)));
      $query = \Drupal::database()->select('months', 'm')
        ->fields('m', ['month_year'])
        ->condition('course_id', $course_id);
      $existing_months = $query->execute()->fetchCol();

      $to_delete = array_diff($existing_months, $new_months);
      if (!empty($to_delete)) {
        foreach ($to_delete as $month_year) {
          \Drupal::database()->delete('months')
            ->condition('course_id', $course_id)
            ->condition('month_year', $month_year)
            ->execute();
        }
      }

      if (!empty($new_months)) {
        foreach ($new_months as $month_year) {
          if (!in_array($month_year, $existing_months)) {
            \Drupal::database()->insert('months')
              ->fields(['course_id' => $course_id, 'month_year' => $month_year])
              ->execute();

          }
        }
      } else {
        \Drupal::messenger()->addError($this->t('No month has been selected for course: @course_name', [
          '@course_name' => $course_name
        ]));
      }
    }

    \Drupal::messenger()->addMessage($this->t('months added successfully.'));
    drupal_flush_all_caches();
  }
}
