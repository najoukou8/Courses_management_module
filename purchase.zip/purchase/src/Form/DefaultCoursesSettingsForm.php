<?php

namespace Drupal\purchase\Form;

use Drupal\Core\Form\FormBase;
use Drupal\Core\Form\FormStateInterface;

/**
 * Class DefaultCoursesSettingsForm.
 */
class DefaultCoursesSettingsForm extends FormBase {


  /**
   * {@inheritdoc}
   */
  public function getFormId() {
    return 'default_courses_settings_form';
  }

  /**
   * {@inheritdoc}
   */
  public function buildForm(array $form, FormStateInterface $form_state) {

    $sql = 'SELECT start_year, end_year FROM {courses_settings}';
    $sql1 = 'SELECT id, course_name, course_duration, course_description FROM {courses}';

    $result = db_query($sql)->fetchAssoc();
    $courses = db_query($sql1)->fetchAll();

    $form['start_year'] = [
      '#type' => 'textfield',
      '#title' => $this->t('start year'),
      '#description' => $this->t('the start year'),
      '#default_value' => !empty($result['start_year']) ? $result['start_year'] : '2024',
      '#weight' => '0',
      '#maxlength' => 4,
    ];
    $form['end_year'] = [
      '#type' => 'textfield',
      '#title' => $this->t('end year'),
      '#description' => $this->t('the end year'),
      '#default_value' => !empty($result['end_year']) ? $result['end_year'] :'2028',
      '#weight' => '0',
      '#maxlength' => 4,
    ];
    foreach ($courses as $i => $course) {
      $course_ids[] = $course->id;

      $form["course_id{$i}"] = [
        '#type' => 'hidden',
        '#value' => $course->id,
      ];

      $form["course_name{$i}"] = [
        '#type' => 'textfield',
        '#title' => $this->t('course name'),
        '#description' => $this->t('the name of the course'),
        '#default_value' => $course->course_name ,
        '#weight' => '0',
      ];
      $form["course_duration{$i}"] = [
        '#type' => 'textfield',
        '#title' => $this->t('course duration'),
        '#description' => $this->t('the courses duration by day'),
        '#default_value' => $course->course_duration ,
        '#weight' => '0',
      ];

      $form["course_description{$i}"] = [
        '#type' => 'textarea',
        '#title' => $this->t('course description'),
        '#description' => $this->t('the description of the course'),
        '#default_value' => $course->course_description ,
        '#weight' => '0',
      ];

   }
    $form['course_ids'] = [
      '#type' => 'hidden',
      '#value' => implode(',', $course_ids),
    ];
    $form['submit'] = [
      '#type' => 'submit',
      '#value' => $this->t('Submit'),
    ];
    $form['#theme'] = 'DefaultCoursesSettingsPage';
    return $form;
  }

  /**
   * {@inheritdoc}
   */
  public function validateForm(array &$form, FormStateInterface $form_state) {
    $start_year= $form_state->getValue('start_year');
    $end_year= $form_state->getValue('end_year');


    if ($end_year< $start_year || $end_year='' || !is_numeric($end_year)) {
      $form_state->setErrorByName('end_year', $this->t('Please enter a valid end year.'));
    }
    if (empty($start_year) || !is_numeric($start_year)) {
      $form_state->setErrorByName('start_year', $this->t('Please enter a valid start year.'));
    }

  }

  /**
   * {@inheritdoc}
   */
  public function submitForm(array &$form, FormStateInterface $form_state) {
    $values = $form_state->getValues();

    foreach ($values as $key => $value) {
      if (strpos($key, 'course_name') === 0) {
          $i = str_replace('course_name', '', $key);
          $course_id = $form_state->getValue("course_id{$i}");
          $course_name = $form_state->getValue("course_name{$i}");
          $course_duration = $form_state->getValue("course_duration{$i}");
          $course_description = $form_state->getValue("course_description{$i}");

          if (!empty($course_id)) {
            \Drupal::database()->update('courses')
            ->fields([
                      'course_name' => $course_name,
                      'course_duration' => $course_duration,
                      'course_description' => $course_description,
                  ])
                  ->condition('id', $course_id)
                  ->execute();
          } else {
            \Drupal::database()->update('courses')
            ->fields([
                      'course_name' => $course_name,
                      'course_duration' => $course_duration,
                      'course_description' => $course_description,
                  ])
                  ->execute();
          }
      }
  }

  drupal_set_message($this->t('Courses have been saved.'));

  $count = \Drupal::database()->query('SELECT COUNT(id) FROM {courses_settings}')->fetchField();
  if ($count > 0) {

    \Drupal::database()->update('courses_settings')
    ->fields(array(
          'start_year'=> $form_state->getValue('start_year'),
          'end_year'=> $form_state->getValue('end_year'),
              ))
     ->execute();


     } else {
      \Drupal::database()->insert('courses_settings')
      ->fields(array(
        'start_year'=> $form_state->getValue('start_year'),
          'end_year'=> $form_state->getValue('end_year'),
               ))
     ->execute();
    }
    drupal_set_message( ' Module has been configured.' ) ;

  }

}
