<?php
namespace Drupal\purchase\Form;

use Drupal\Core\Form\FormBase;
use Drupal\Core\Form\FormStateInterface;

class PurchaseListForm extends FormBase {

  public function getFormId() {
    return 'purchase_list_form';
  }

  public function buildForm(array $form, FormStateInterface $form_state) {
    $search = \Drupal::request()->query->get('search', '');
    $sort_column = \Drupal::request()->query->get('sort_column', 'client_name');
    $sort_order = \Drupal::request()->query->get('sort_order', 'asc');

    $form['title'] = [
      '#markup' => '<h1>Subscriptions List</h1>',
    ];

    $form['search'] = [
      '#type' => 'textfield',
      '#title' => $this->t('Search'),
      '#default_value' => $search,
    ];

    $form['sort_column'] = [
      '#type' => 'select',
      '#title' => $this->t('Sort by'),
      '#options' => [
        'client_name' => $this->t('Client Name'),
        'course_name' => $this->t('Course Name'),
        'datetime' => $this->t('Datetime'),
        'state' => $this->t('State'),
      ],
      '#default_value' => $sort_column,
    ];

    $form['sort_order'] = [
      '#type' => 'select',
      '#title' => $this->t('Sort order'),
      '#options' => [
        'asc' => $this->t('Ascending'),
        'desc' => $this->t('Descending'),
      ],
      '#default_value' => $sort_order,
    ];

    $form['actions']['submit'] = [
      '#type' => 'submit',
      '#value' => $this->t('Apply'),
      '#button_type' => 'primary',
    ];

    return $form;
  }

  public function submitForm(array &$form, FormStateInterface $form_state) {
    $search = $form_state->getValue('search');
    $sort_column = $form_state->getValue('sort_column');
    $sort_order = $form_state->getValue('sort_order');

    $form_state->setRedirect('purchase.purchase_list_controller_content', [], [
      'query' => [
        'search' => $search,
        'sort_column' => $sort_column,
        'sort_order' => $sort_order,
      ],
    ]);

  }
}

