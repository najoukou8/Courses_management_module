<?php

namespace Drupal\purchase\Tests;

use Drupal\simpletest\WebTestBase;

/**
 * Provides automated tests for the purchase module.
 */
class MonthsControllerTest extends WebTestBase {


  /**
   * {@inheritdoc}
   */
  public static function getInfo() {
    return [
      'name' => "purchase MonthsController's controller functionality",
      'description' => 'Test Unit for module purchase and controller MonthsController.',
      'group' => 'Other',
    ];
  }

  /**
   * {@inheritdoc}
   */
  public function setUp() {
    parent::setUp();
  }

  /**
   * Tests purchase functionality.
   */
  public function testMonthsController() {
    // Check that the basic functions of module purchase.
    $this->assertEquals(TRUE, TRUE, 'Test Unit Generated via Drupal Console.');
  }

}
