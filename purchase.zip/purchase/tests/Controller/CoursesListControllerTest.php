<?php

namespace Drupal\purchase\Tests;

use PHPUnit\Framework\TestCase;

/**
 * Provides automated tests for the purchase module.
 */
class CoursesListControllerTest extends TestCase  {


  /**
   * {@inheritdoc}
   */
  public static function getInfo() {
    return [
      'name' => "purchase CoursesListController's controller functionality",
      'description' => 'Test Unit for module purchase and controller CoursesListController.',
      'group' => 'Other',
    ];
  }

  /**
   * {@inheritdoc}
   */
  public function setUp() {
    parent::setUp();
  }

  /**
   * Tests purchase functionality.
   */
  public function testCoursesListController() {
    // Check that the basic functions of module purchase.
    $this->assertEquals(TRUE, TRUE, 'Test Unit Generated via Drupal Console.');
  }

}
