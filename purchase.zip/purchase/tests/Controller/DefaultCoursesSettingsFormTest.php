<?php
namespace Drupal\purchase\Tests;

use Drupal\Core\Form\FormStateInterface;
use Drupal\purchase\Form\DefaultCoursesSettingsForm;
use PHPUnit\Framework\TestCase;

/**
 * Test class for DefaultCoursesSettingsForm.
 */
class DefaultCoursesSettingsFormTest extends TestCase {

  /**
   * The form object.
   *
   * @var \Drupal\purchase\Form\DefaultCoursesSettingsForm
   */
  private $form;

  /**
   * {@inheritdoc}
   */
  protected function setUp(): void {
    parent::setUp();

    $this->form = new DefaultCoursesSettingsForm();
  }

  /**
   * Test the form ID.
   */
  public function testFormId() {
    $this->assertEquals('default_courses_settings_form', $this->form->getFormId());
  }

  /**
   * Test the form structure.
   */
  public function testBuildForm() {
    $form_state = $this->createMock(FormStateInterface::class);


    $form = $this->form->buildForm([], $form_state);


    $this->assertArrayHasKey('start_year', $form);
    $this->assertArrayHasKey('end_year', $form);
    $this->assertArrayHasKey('submit', $form);
  }


}
